/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _XT_MARK_H_target
#define _XT_MARK_H_target

#include <linux/netfilter/xt_mark.h>

#endif /*_XT_MARK_H_target */
